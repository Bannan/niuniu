
$(function(){
console.log(11111)
 function createBull9() {
        $(".createRoom .mainPart").css("height", "71vh")
        $(".createRoom .mainPart .blueBack").css("height", "50vh")
    }








})



