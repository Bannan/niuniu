<?php
namespace app\index\controller;
/*
 * 首页
 */
class index extends Common
{


    public function index()
    {
        return view();
    }


}
