<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"E:\WWW\pro_wx_smartadmin\public/../application/index\view\login\index.html";i:1513581854;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0">
  <meta name="format-detection" content="telephone=no">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <title>留存</title>
  <!--公共样式与插件-->
  <script type="text/javascript" src="__PUBLIC__js/rem.js"></script>
  <link rel="stylesheet" href="__PUBLIC__css/common.css">
  <!--公共样式与插件 end-->
  <link rel="stylesheet" href="__PUBLIC__css/layui.css">
  <link rel="stylesheet" href="__PUBLIC__css/base.css">
</head>
<body>
	<div class="login">
		<div class="login-title">Admin 后台管理系统</div>
		<form class="layui-form login-form" method="post">
		    <div class="layui-form-item">
				<label class="layui-form-label">用户名</label>
				<div class="layui-input-block">
					<input type="text" name="name" autocomplete="off" class="layui-input">
				</div>
			</div>
			<div class="layui-form-item">
				<label class="layui-form-label">密码</label>
				<div class="layui-input-block">
					<input type="password" name="pass" class="layui-input">
				</div>
			</div>
			<div class="layui-form-item">
				<label class="layui-form-label">验证码</label>
				<div class="layui-input-block">
					<input id="j_verify" name="captcha" type="text" class="layui-input layui-input-inline">
					<img id="verify_img"  class="captcha" alt="点击更换" title="点击更换" src="<?php echo captcha_src(); ?>" alt="captcha" onclick="javascript:this.src='<?php echo captcha_src(); ?>?tm='+Math.random();" style="cursor: pointer"/>
				</div>
			</div>
			<div class="layui-form-item">
				<div class="layui-input-block">
					<button class="layui-btn" id="yan-login-btn" type="submit">登 录</button>
				</div>
			</div>
		</form>
	</div>
	
	<script src="__PUBLIC__js/jquery.min.js"></script>
	<script>
		
	</script>
</body>
</html>