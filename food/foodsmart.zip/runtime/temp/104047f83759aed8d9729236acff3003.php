<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:63:"E:\WWW\foodsmart/application/index\view\order\order_statis.html";i:1513839900;s:56:"E:\WWW\foodsmart/application/index\view\public\head.html";i:1513931802;s:55:"E:\WWW\foodsmart/application/index\view\public\nav.html";i:1513931802;s:58:"E:\WWW\foodsmart/application/index\view\public\footer.html";i:1513735872;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0">
  <meta name="format-detection" content="telephone=no">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <title>订单统计</title>
  <!--公共样式与插件-->
  <link rel="stylesheet" href="__PUBLIC__js/layui/css/layui.css">
  <link rel="stylesheet" href="__PUBLIC__css/common.css">
  <!--公共样式与插件 end-->
  <link rel="stylesheet" href="__PUBLIC__css/base.css">
</head>
<body>
<div class="layui-layout layui-layout-admin">
	<div class="layui-header header header-demo headerWrap">
	<div class="layui-main">
		<a class="logo" href="/">
		<img src="__PUBLIC__images/admin_logo.png" alt="layui">
		</a>
		<ul class="layui-nav">
			<li class="layui-nav-item"><a href="#">AdminUser<span class="layui-badge-dot"></span></a></li>
			<li class="layui-nav-item">
				<a href="<?php echo url('login/loginout'); ?>">退出登录</a>
			</li>
		</ul>
	</div>
</div>
	<div class="layui-side layui-bg-black slideWrap">
	<ul class="layui-nav layui-nav-tree" id="layui_nav">
		<li class="layui-nav-item">
			<a href="javascript:;" target="_blank">
				<i class="layui-icon">&#xe615;</i> 首页
			</a>
		</li>
		<li class="layui-nav-item">
			<a href="javascript:;">
				<i class="layui-icon">&#xe63c;</i>库存首页<span class="layui-nav-more"></span>
			</a>
			<dl class="layui-nav-child">
				<dd class="<?php if($action == 'indexStock') echo 'layui-this';?>">
					<a href="<?php echo url('stock/index'); ?>">当前库存</a>
				</dd>
				<dd class="<?php if($action == 'record_hpStock' || $action == 'add_foodStock') echo 'layui-this';?>">
					<a href="<?php echo url('stock/record_hp'); ?>">货品列表</a>
				</dd>
				<dd class="<?php if($action == 'record_ylStock' || $action == 'add_ylStock') echo 'layui-this';?>">
					<a href="<?php echo url('stock/record_yl'); ?>">原料列表</a>
				</dd>
			</dl>
		</li>
		<li class="layui-nav-item">
			<a href="javascript:;">
				<i class="layui-icon">&#xe64f;</i>订单首页<span class="layui-nav-more"></span>
			</a>
			<dl class="layui-nav-child">
				<dd class="<?php if($action == 'indexOrder' || $action == 'order_editOrder' || $action == 'order_infoOrder') echo 'layui-this';?>">
					<a href="<?php echo url('order/index'); ?>">订单记录</a>
				</dd>
				<dd class="<?php if($action == 'order_ypOrder' || $action == 'order_yp_editOrder') echo 'layui-this';?>">
					<a href="<?php echo url('order/order_yp'); ?>">样品记录</a>
				</dd>
				<dd class="<?php if($action == 'order_statisOrder') echo 'layui-this';?>">
					<a href="<?php echo url('order/order_statis'); ?>">订单统计</a>
				</dd>
			</dl>
		</li>
		<li class="layui-nav-item">
			<a href="javascript:;">
				<i class="layui-icon">&#xe65e;</i>财务首页<span class="layui-nav-more"></span>
			</a>
			<dl class="layui-nav-child ">
				<dd class="<?php if($action == 'indexFinance') echo 'layui-this';?>">
					<a href="<?php echo url('finance/index'); ?>">营业收入</a>
				</dd>
				<dd class="<?php if($action == 'accountFinance') echo 'layui-this';?>">
					<a href="<?php echo url('finance/account'); ?>">已收账款</a>
				</dd>
				<dd class="<?php if($action == 'account_okFinance') echo 'layui-this';?>">
					<a href="<?php echo url('finance/account_ok'); ?>">应收账款</a>
				</dd>
				<dd class="<?php if($action == 'priceFinance' || $action == 'price_editFinance') echo 'layui-this';?>">
					<a href="<?php echo url('finance/price'); ?>">价格体系</a>
				</dd>
			</dl>
		</li>
		<span class="layui-nav-bar" style="top: 22.5px; height: 0px; opacity: 0;"></span>
	</ul>
</div>


<!--手机端导航-->
<div class="mNavWrap">
<div class="mHeader">
  <div class="toggle">
    <a href="javascript:void(0)" class="burger-btn" id="burger-btn" data-on="on">
      <span class="burger burger-1 trans"></span>
      <span class="burger burger-3 trans"></span>
    </a>
  </div>
  <a href="#" class="logo">后台管理系统</a>
</div>
<div class="mNavSecond openMneu">
  <div class="main">
    <ul class="menu" id="menu">
    	<li>
       		<a href="<?php echo url('stock/index'); ?>"><span class="ico">首页</span></a>
        </li>
      <li>
        <a href="javascript:;"><span class="ico">库存首页</span></a>
        <dl class="subMenu" style="display: none;">
          	<dd class="<?php if($action == 'indexStock') echo 'layui-this';?>">
				<a href="<?php echo url('stock/index'); ?>">当前库存</a>
			</dd>
			<dd class="<?php if($action == 'record_hpStock') echo 'layui-this';?>">
				<a href="<?php echo url('stock/record_hp'); ?>">货品列表</a>
			</dd>
			<dd class="<?php if($action == 'record_ylStock') echo 'layui-this';?>">
				<a href="<?php echo url('stock/record_yl'); ?>">原料列表</a>
			</dd>
        </dl>
      </li>
      <li>
        <a href="javascript:;"><span class="ico">订单首页</span><i></i></a>
        <dl class="subMenu" style="display: none;">
          	<dd class="<?php if($action == 'indexOrder') echo 'layui-this';?>">
				<a href="<?php echo url('order/index'); ?>">订单记录</a>
			</dd>
			<dd class="<?php if($action == 'order_ypOrder') echo 'layui-this';?>">
				<a href="<?php echo url('order/order_yp'); ?>">样品记录</a>
			</dd>
			<dd class="<?php if($action == 'order_statisOrder') echo 'layui-this';?>">
				<a href="<?php echo url('order/order_statis'); ?>">订单统计</a>
			</dd>
        </dl>
      </li>
      <li>
        <a href="javascript:;"><span class="ico">财务首页</span><i></i></a>
        <dl class="subMenu" style="display: none;">
          	<dd class="<?php if($action == 'indexFinance') echo 'layui-this';?>">
				<a href="<?php echo url('finance/index'); ?>">营业收入</a>
			</dd>
			<dd class="<?php if($action == 'accountFinance') echo 'layui-this';?>">
				<a href="<?php echo url('finance/account'); ?>">已收账款</a>
			</dd>
			<dd class="<?php if($action == 'account_okFinance') echo 'layui-this';?>">
				<a href="<?php echo url('finance/account_ok'); ?>">应收账款</a>
			</dd>
			<dd class="<?php if($action == 'priceFinance') echo 'layui-this';?>">
				<a href="<?php echo url('finance/price'); ?>">价格体系</a>
			</dd>
        </dl>
      </li>
    </ul>
    <p class="bottom"><a href="<?php echo url('login/loginout'); ?>"><span>退出登录</span></a></p>
  </div>
</div>
</div>
<!--手机端导航 end-->

























	<!--主要内容-->
	<div class="layui-body site-demo">
		<!--tab标签-->
		<div class="layui-main">
			<blockquote class="layui-elem-quote">
 				<a class="layui-btn" href="javascript:;">订单统计</a>
			</blockquote>
			<form class="layui-form layui-form-pane" action="">
				<div class="layui-form-item">
					<div class="layui-inline">
						<label class="layui-form-label">下单起始日期</label>
						<div class="layui-input-block">
							<input type="text" name="date" id="time1" value="<?php echo $date['start'][0]; ?>" class="layui-input" placeholder="">
						</div>
					</div>
					<div class="layui-inline">
						<label class="layui-form-label">下单截止日期</label>
						<div class="layui-input-inline">
							<input type="text" name="number" value="<?php echo $date['start'][1]; ?>" id="time2" class="layui-input" placeholder="">
						</div>
					</div>
				</div>
				<div class="layui-form-item">
					<div class="layui-inline">
						<label class="layui-form-label">回款起始日期</label>
						<div class="layui-input-block">
							<input type="text" name="date" id="time3" value="<?php echo $date['end'][0]; ?>" class="layui-input" placeholder="">
						</div>
					</div>
					<div class="layui-inline">
						<label class="layui-form-label">回款截止日期</label>
						<div class="layui-input-inline">
							<input type="text" name="number" id="time4" value="<?php echo $date['end'][1]; ?>" class="layui-input" placeholder="">
						</div>
					</div>
				</div>
				<div class="layui-form-item">
					<button class="layui-btn" type="button" lay-filter="demo2" id="search_btn">搜索</button>
				</div>
				<div class="layui-form-item">
					<div class="layui-inline">
						<label class="layui-form-label">订单数量</label>
						<div class="layui-input-block">
							<input type="text" name="date" id="date1" class="layui-input" lay-key="2" placeholder="<?php echo $food[0]['count']; ?>个" readonly>
						</div>
					</div>
					<div class="layui-inline">
						<label class="layui-form-label">订单金额</label>
						<div class="layui-input-inline">
							<input type="text" name="number" class="layui-input"  placeholder="<?php echo $food[0]['price']; ?>元" readonly>
						</div>
					</div>
				</div>
			</form>
			<div class="layui-tab-item layui-show">
				<table class="layui-table layui-table-w">
					<thead>
						<tr>
							<th class="w">排序</th>
							<th>经办人</th>
							<th>订单数量</th>
							<th>订单金额</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach($data as $k=>$v){?>
						<tr>
							<td><?php echo $k+1; ?></td>
							<td><?php echo $v['admin_user']; ?></td>
							<td><?php echo $v['count']; ?></td>
							<td><?php echo $v['sum']; ?></td>
						</tr>
					<?php }?>
					</tbody>
				</table>
			</div>
			<div class="layui-tab-item layui-show">
				<table class="layui-table layui-table-w">
					<thead>
						<tr>
							<th class="w">排序</th>
							<th>品名</th>
							<th>订单数量</th>
							<th>订单金额</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach($food_list as $k=>$v){?>
						<tr>
							<td><?php echo $k+1; ?></td>
							<td><?php echo food_name($v['fid'])['name']; ?></td>
							<td><?php echo $v['number']; ?></td>
							<td><?php echo $v['price']; ?></td>
						</tr>
					<?php }?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!--主要内容 end-->
	<div class="layui-footer footer footer-demo footerWrap">
	<div class="layui-main">
		<p>
			2016 © <a href="#" target="_blank">Think Admin</a>
		</p>
	</div>
</div>
<script src="__PUBLIC__js/layui/layui.js"></script>
<script>layui.config({base: '__PUBLIC__js/modules/' }).use('index');</script>
<script src="__PUBLIC__js/jquery.min.js"></script>
	<script>
		$(function() {
			$('#search_btn').on('click', function() {
				var time1 = $('#time1').val();
				var time2 = $('#time2').val();
				var time3 = $('#time3').val();
				var time4 = $('#time4').val();
				var url = "/foodsmart/index.php/index/order/order_statis.html";
				window.location.href = ''+url+'?start='+time1+'~'+time2+'&end='+time3+'~'+time4+'';
			});
		});
	</script>
</div>
</body>
</html>