<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:81:"E:\WWW\pro_wx_smartadmin\public/../application/index\view\index\hkxq_history.html";i:1513580633;s:72:"E:\WWW\pro_wx_smartadmin\public/../application/index\view\index\nav.html";i:1513327005;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0">
  <meta name="format-detection" content="telephone=no">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <title>号库详情</title>
  <!--公共样式与插件-->
  <script type="text/javascript" src="__PUBLIC__js/rem.js"></script>
  <link rel="stylesheet" href="__PUBLIC__css/common.css">
  <!--公共样式与插件 end-->
  <link rel="stylesheet" href="__PUBLIC__css/base.css">
</head>
<body>
	<div class="wrap">
		<div class="headerWrap">
	<ul>
		<li class="<?php if($action == 'hkgl') echo 'active';?>">
			<a href="<?php echo url('index/hkgl'); ?>">号库概览</a>
		</li>
		<li class="<?php if($action == 'hkxq') echo 'active';?>">
			<a href="<?php echo url('index/hkxq'); ?>">号库详情</a>
		</li>
		<li class="<?php if($action == 'zc') echo 'active';?>">
			<a href="<?php echo url('index/zc'); ?>">注册</a>
		</li>
		<li class="<?php if($action == 'lc') echo 'active';?>">
			<a href="<?php echo url('index/lc'); ?>">留存</a>
		</li>
		<li class="<?php if($action == 'dd') echo 'active';?>">
			<a href="<?php echo url('index/dd'); ?>">订单</a>
		</li>
		<li class="<?php if($action == 'hkcz') echo 'active';?>">
			<a href="<?php echo url('index/hkcz'); ?>">号库操作</a>
		</li>
	</ul>
</div>
		<div class="back-wrap">
			<a href="javascript:history.go(-1)">返回</a>
		</div>
		<div class="main-details">
			<table class="table">
				<thead>
					<tr>
						<th>库号</th>
						<th>数量</th>
						<th>8日号</th>
						<th>半月号</th>
						<th>满月号</th>
						<th>半年号</th>
						<th>历史记录</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach($list as $k=>$v){?>
					<tr>
						<td><?php echo $v['base_number']; ?></td>
						<td><?php echo $v['number']; ?></td>
						<td><?php echo $v['8day']; ?></td>
						<td><?php echo $v['half_a_moon']; ?></td>
						<td><?php echo $v['full_moon']; ?></td>
						<td><?php echo $v['half_a_year']; ?></td>
						<td><?php echo date('Y-m-d H:i:s',$v['time']);?></td>
					</tr> 
				<?php }?>
				</tbody>
	        </table>  
	    </div>
      	<!--分页-->
        <div class="pageSize">
			<div class="box">
				<?php echo $list->render(); ?>
			</div>
		</div>


	</div>
	
	<script src="__PUBLIC__js/jquery.min.js"></script>
	<script src="__PUBLIC__js/base.js"></script>
</body>
</html>