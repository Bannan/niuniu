<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:56:"E:\WWW\foodsmart/application/index\view\index\index.html";i:1513584798;}*/ ?>
asdas