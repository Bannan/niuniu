<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:58:"E:\WWW\foodsmart/application/index\view\finance\price.html";i:1513925004;s:56:"E:\WWW\foodsmart/application/index\view\public\head.html";i:1513931802;s:55:"E:\WWW\foodsmart/application/index\view\public\nav.html";i:1513931802;s:58:"E:\WWW\foodsmart/application/index\view\public\footer.html";i:1513735872;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0">
  <meta name="format-detection" content="telephone=no">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <title>价格体系</title>
  <!--公共样式与插件-->
  <link rel="stylesheet" href="__PUBLIC__js/layui/css/layui.css">
  <link rel="stylesheet" href="__PUBLIC__css/common.css">
  <!--公共样式与插件 end-->
  <link rel="stylesheet" href="__PUBLIC__css/base.css">
</head>
<body>
<div class="layui-layout layui-layout-admin">
	<div class="layui-header header header-demo headerWrap">
	<div class="layui-main">
		<a class="logo" href="/">
		<img src="__PUBLIC__images/admin_logo.png" alt="layui">
		</a>
		<ul class="layui-nav">
			<li class="layui-nav-item"><a href="#">AdminUser<span class="layui-badge-dot"></span></a></li>
			<li class="layui-nav-item">
				<a href="<?php echo url('login/loginout'); ?>">退出登录</a>
			</li>
		</ul>
	</div>
</div>
	<div class="layui-side layui-bg-black slideWrap">
	<ul class="layui-nav layui-nav-tree" id="layui_nav">
		<li class="layui-nav-item">
			<a href="javascript:;" target="_blank">
				<i class="layui-icon">&#xe615;</i> 首页
			</a>
		</li>
		<li class="layui-nav-item">
			<a href="javascript:;">
				<i class="layui-icon">&#xe63c;</i>库存首页<span class="layui-nav-more"></span>
			</a>
			<dl class="layui-nav-child">
				<dd class="<?php if($action == 'indexStock') echo 'layui-this';?>">
					<a href="<?php echo url('stock/index'); ?>">当前库存</a>
				</dd>
				<dd class="<?php if($action == 'record_hpStock' || $action == 'add_foodStock') echo 'layui-this';?>">
					<a href="<?php echo url('stock/record_hp'); ?>">货品列表</a>
				</dd>
				<dd class="<?php if($action == 'record_ylStock' || $action == 'add_ylStock') echo 'layui-this';?>">
					<a href="<?php echo url('stock/record_yl'); ?>">原料列表</a>
				</dd>
			</dl>
		</li>
		<li class="layui-nav-item">
			<a href="javascript:;">
				<i class="layui-icon">&#xe64f;</i>订单首页<span class="layui-nav-more"></span>
			</a>
			<dl class="layui-nav-child">
				<dd class="<?php if($action == 'indexOrder' || $action == 'order_editOrder' || $action == 'order_infoOrder') echo 'layui-this';?>">
					<a href="<?php echo url('order/index'); ?>">订单记录</a>
				</dd>
				<dd class="<?php if($action == 'order_ypOrder' || $action == 'order_yp_editOrder') echo 'layui-this';?>">
					<a href="<?php echo url('order/order_yp'); ?>">样品记录</a>
				</dd>
				<dd class="<?php if($action == 'order_statisOrder') echo 'layui-this';?>">
					<a href="<?php echo url('order/order_statis'); ?>">订单统计</a>
				</dd>
			</dl>
		</li>
		<li class="layui-nav-item">
			<a href="javascript:;">
				<i class="layui-icon">&#xe65e;</i>财务首页<span class="layui-nav-more"></span>
			</a>
			<dl class="layui-nav-child ">
				<dd class="<?php if($action == 'indexFinance') echo 'layui-this';?>">
					<a href="<?php echo url('finance/index'); ?>">营业收入</a>
				</dd>
				<dd class="<?php if($action == 'accountFinance') echo 'layui-this';?>">
					<a href="<?php echo url('finance/account'); ?>">已收账款</a>
				</dd>
				<dd class="<?php if($action == 'account_okFinance') echo 'layui-this';?>">
					<a href="<?php echo url('finance/account_ok'); ?>">应收账款</a>
				</dd>
				<dd class="<?php if($action == 'priceFinance' || $action == 'price_editFinance') echo 'layui-this';?>">
					<a href="<?php echo url('finance/price'); ?>">价格体系</a>
				</dd>
			</dl>
		</li>
		<span class="layui-nav-bar" style="top: 22.5px; height: 0px; opacity: 0;"></span>
	</ul>
</div>


<!--手机端导航-->
<div class="mNavWrap">
<div class="mHeader">
  <div class="toggle">
    <a href="javascript:void(0)" class="burger-btn" id="burger-btn" data-on="on">
      <span class="burger burger-1 trans"></span>
      <span class="burger burger-3 trans"></span>
    </a>
  </div>
  <a href="#" class="logo">后台管理系统</a>
</div>
<div class="mNavSecond openMneu">
  <div class="main">
    <ul class="menu" id="menu">
    	<li>
       		<a href="<?php echo url('stock/index'); ?>"><span class="ico">首页</span></a>
        </li>
      <li>
        <a href="javascript:;"><span class="ico">库存首页</span></a>
        <dl class="subMenu" style="display: none;">
          	<dd class="<?php if($action == 'indexStock') echo 'layui-this';?>">
				<a href="<?php echo url('stock/index'); ?>">当前库存</a>
			</dd>
			<dd class="<?php if($action == 'record_hpStock') echo 'layui-this';?>">
				<a href="<?php echo url('stock/record_hp'); ?>">货品列表</a>
			</dd>
			<dd class="<?php if($action == 'record_ylStock') echo 'layui-this';?>">
				<a href="<?php echo url('stock/record_yl'); ?>">原料列表</a>
			</dd>
        </dl>
      </li>
      <li>
        <a href="javascript:;"><span class="ico">订单首页</span><i></i></a>
        <dl class="subMenu" style="display: none;">
          	<dd class="<?php if($action == 'indexOrder') echo 'layui-this';?>">
				<a href="<?php echo url('order/index'); ?>">订单记录</a>
			</dd>
			<dd class="<?php if($action == 'order_ypOrder') echo 'layui-this';?>">
				<a href="<?php echo url('order/order_yp'); ?>">样品记录</a>
			</dd>
			<dd class="<?php if($action == 'order_statisOrder') echo 'layui-this';?>">
				<a href="<?php echo url('order/order_statis'); ?>">订单统计</a>
			</dd>
        </dl>
      </li>
      <li>
        <a href="javascript:;"><span class="ico">财务首页</span><i></i></a>
        <dl class="subMenu" style="display: none;">
          	<dd class="<?php if($action == 'indexFinance') echo 'layui-this';?>">
				<a href="<?php echo url('finance/index'); ?>">营业收入</a>
			</dd>
			<dd class="<?php if($action == 'accountFinance') echo 'layui-this';?>">
				<a href="<?php echo url('finance/account'); ?>">已收账款</a>
			</dd>
			<dd class="<?php if($action == 'account_okFinance') echo 'layui-this';?>">
				<a href="<?php echo url('finance/account_ok'); ?>">应收账款</a>
			</dd>
			<dd class="<?php if($action == 'priceFinance') echo 'layui-this';?>">
				<a href="<?php echo url('finance/price'); ?>">价格体系</a>
			</dd>
        </dl>
      </li>
    </ul>
    <p class="bottom"><a href="<?php echo url('login/loginout'); ?>"><span>退出登录</span></a></p>
  </div>
</div>
</div>
<!--手机端导航 end-->

























	<!--主要内容-->
	<div class="layui-body site-demo webWrap">
		<!--tab标签-->
		<div class="layui-main">
			<blockquote class="layui-elem-quote">
 				<a class="layui-btn" href="javascript:;">价格体系</a>
			</blockquote>
			<div class="layui-form">
				<div class="layui-form-item layui-form-item-jgtx">
					<div class="layui-input-block">
						<select name="parentid" id="select-channel" lay-verify="required">

							<?php foreach($option as $k=>$v){?>

							<option value="<?php echo $v['id']; ?>"  <?php if($data['id'] == $v['id'])echo "selected";?>><?php echo $v['channel']; ?></option>

							<?php }?>
						</select>
						<div class="layui-unselect layui-form-select">
							<dl class="layui-anim layui-anim-upbit">

								<?php foreach($option as $k=>$v){?>

								<dd lay-value="<?php echo $v['id']; ?>" class=""><?php echo $v['channel']; ?></dd>

								<?php }?>
							</dl>
						</div>
					</div>
					<a href="#" id="show" class="layui-btn">查看</a>
					<a href="#" id="edit" class="layui-btn">编辑</a>
					<a href="#" id="add" class="layui-btn">新增价格</a>
				</div>
			</div>
			<fieldset class="layui-elem-field layui-field-title">
			  <legend>流通</legend>
			</fieldset>
			<div class="layui-tab-item layui-show layui-tab-item-jgtx">
				<table class="layui-table layui-table-w">
					<thead>
						<tr>
							<th class="w">排序</th>
							<th>品名</th>
							<th>价格</th>
							<th>毛利</th>
						</tr>
					</thead>
					<tbody>
					<?php if($data['price']){ foreach(json_decode($data['price'],true) as $k=>$v){?>
						<tr>
							<td><?php echo $v[0];?></td>
							<td><?php echo food_name($v[0])['name'];?></td>
							<td><?php echo $v[1];?></td>
							<td><?php echo $v[2];?></td>
						</tr>
					<?php }}?>
					</tbody>
				</table>  
			</div>
		</div>
	</div>
	<div class="layui-footer footer footer-demo footerWrap">
	<div class="layui-main">
		<p>
			2016 © <a href="#" target="_blank">Think Admin</a>
		</p>
	</div>
</div>
<script src="__PUBLIC__js/layui/layui.js"></script>
<script>layui.config({base: '__PUBLIC__js/modules/' }).use('index');</script>
<script src="__PUBLIC__js/jquery.min.js"></script>
	<script>
		$(function(){
		    $("#show").on("click",function(){
				window.location.href="<?php echo url('finance/price'); ?>?channel="+$("#select-channel").val();
			})
			$("#edit").on("click",function(){
				if ($('#select-channel').val() == null) {
					return false;
				}
				window.location.href="<?php echo url('finance/price_edit'); ?>?type=edit&id="+$("#select-channel").val();
			});
		    $("#add").on("click",function(){
		        window.location.href="<?php echo url('finance/price_edit'); ?>";
			})

		});
	</script>
</div>
</body>
</html>